# Odyssey-Resource-Pack

The official pack required for models, textures, and more for the Minecraft Odyssey Plugin!
