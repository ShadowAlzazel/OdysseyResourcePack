# Odyssey-Resource-Pack

The official pack required for models, textures, and more for the Minecraft Odyssey Plugin and Datapack

All Music Belongs to T_en_M (https://www.youtube.com/@TenM)
